import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class Catatan {
  final int? id;
  final String judul;
  final String isi;

  const Catatan({this.id, required this.judul, required this.isi});

  Map<String, Object?> toMap() => {
        'id': id,
        'judul': judul,
        'isi': isi,
      };

  factory Catatan.fromMap(Map<String, Object?> map) => Catatan(
        id: map['id'] as int,
        judul: map['judul'] as String,
        isi: map['isi'] as String,
      );
}

class DbHelper {
  static Database? _db;

  static Future<Database> get database async {
    if (_db != null) return _db!;
    final dbPath = p.join(await getDatabasesPath(), 'catatan.db');
    _db = await openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) => db.execute(
        'CREATE TABLE catatan('
        'id INTEGER PRIMARY KEY AUTOINCREMENT, '
        'judul TEXT NOT NULL, '
        'isi TEXT NOT NULL)',
      ),
    );
    return _db!;
  }

  static Future<int> tambah(Catatan catatan) async {
    final db = await database;
    return db.insert('catatan', catatan.toMap());
  }

  static Future<List<Catatan>> semua() async {
    final db = await database;
    final rows = await db.query('catatan', orderBy: 'id DESC');
    return rows.map(Catatan.fromMap).toList();
  }

  static Future<int> ubah(Catatan catatan) async {
    final db = await database;
    return db.update(
      'catatan',
      catatan.toMap(),
      where: 'id = ?',
      whereArgs: [catatan.id],
    );
  }

  static Future<int> hapus(int id) async {
    final db = await database;
    return db.delete('catatan', where: 'id = ?', whereArgs: [id]);
  }
}
